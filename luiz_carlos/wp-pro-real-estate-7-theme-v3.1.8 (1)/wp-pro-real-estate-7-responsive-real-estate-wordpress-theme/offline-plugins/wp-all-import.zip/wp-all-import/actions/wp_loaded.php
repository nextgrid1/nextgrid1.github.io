<?php

function pmxi_wp_loaded() {				
	
}