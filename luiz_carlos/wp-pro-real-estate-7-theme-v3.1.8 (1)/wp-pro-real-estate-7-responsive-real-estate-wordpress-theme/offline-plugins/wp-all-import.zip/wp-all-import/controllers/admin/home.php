<?php 
/**
 * Admin Home page
 * 
 * @author Pavel Kulbakin <p.kulbakin@gmail.com>
 */
class PMXI_Admin_Home extends PMXI_Controller_Admin {
	
	public function index() {
		$this->render();
	}
}