<?php
/**
 * Disable direct file access.
 */
if ( ! defined('ABSPATH') ) {
	return;
}

get_template_part( 'includes/single-listing-header' );
