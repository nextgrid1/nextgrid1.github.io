<?php
namespace CT_Elementor_Widgets;

/**
 * Class Plugin
 *
 * Main Plugin class
 * @since 1.2.0
 */
class Plugin {

	/**
	 * Instance
	 *
	 * @since 1.2.0
	 * @access private
	 * @static
	 *
	 * @var Plugin The single instance of the class.
	 */
	private static $_instance = null;

	/**
	 * Instance
	 *
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @since 1.2.0
	 * @access public
	 *
	 * @return Plugin An instance of the class.
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * widget_scripts
	 *
	 * Load required plugin core files.
	 *
	 * @since 1.2.0
	 * @access public
	 */
	public function widget_scripts() {
		//wp_register_script( 'elementor-hello-world', plugins_url( '/assets/js/hello-world.js', __FILE__ ), [ 'jquery' ], false, true );
	}

	/**
	 * Include Widgets files
	 *
	 * Load widgets files
	 *
	 * @since 1.2.0
	 * @access private
	 */
	private function include_widgets_files() {
		require_once( __DIR__ . '/widgets/ct-listings-search.php' );
		require_once( __DIR__ . '/widgets/ct-listings-grid.php' );
		require_once( __DIR__ . '/widgets/ct-listings-list.php' );
		require_once( __DIR__ . '/widgets/ct-listings-minimal-grid.php' );
		require_once( __DIR__ . '/widgets/ct-listings-carousel.php' );
		require_once( __DIR__ . '/widgets/ct-listings-table.php' );
		require_once( __DIR__ . '/widgets/ct-listings-map.php' );
		require_once( __DIR__ . '/widgets/ct-modern-four-item-grid.php' );
		require_once( __DIR__ . '/widgets/ct-modern-item-grid.php' );
		require_once( __DIR__ . '/widgets/ct-three-item-grid.php' );
		require_once( __DIR__ . '/widgets/ct-six-item-grid.php' );
		require_once( __DIR__ . '/widgets/ct-agent.php' );
		require_once( __DIR__ . '/widgets/ct-city-links.php' );
		
		if(function_exists('elementor_pro_load_plugin')) {
			require_once( __DIR__ . '/widgets/ct-login-register-user-drop.php' );
			require_once( __DIR__ . '/widgets/ct-header-listings-search.php' );
		}
	}

	/**
	 * Register Widgets
	 *
	 * Register new Elementor widgets.
	 *
	 * @since 1.2.0
	 * @access public
	 */
	public function register_widgets() {
		// Its is now safe to include Widgets files
		$this->include_widgets_files();

		// Register Widgets
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\CT_Listings_Search() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\CT_Listings_Grid() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\CT_Listings_List() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\CT_Listings_Minimal_Grid() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\CT_Listings_Carousel() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\CT_Listings_Table() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\CT_Listings_Map() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\CT_Agent() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\CT_City_Links() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\CT_Three_Item_Grid() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\CT_Six_Item_Grid() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\CT_Modern_Four_Item_Grid() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\CT_Modern_Item_Grid() );
		
		if(function_exists('elementor_pro_load_plugin')) {
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\CT_Login_Register_User_Drop() );
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\CT_Header_Listings_Search() );
		}
	}

	/**
	 *  Load Templates
	 *
	 * Import premade RE7 templates & blocks to "My Templates" tab
	 *
	 * @since 1.2.0
	 * @access public
	 */
	public function importTemplates() {  
        $fileContent = file_get_contents( __DIR__ . '/templates/elementor-demo-two-neighborhood.json' );  
        \Elementor\Plugin::instance()->templates_manager->import_template( [  
                'fileData' => base64_encode( $fileContent ),  
                'fileName' => 'elementor-demo-two-neighborhood.json',  
            ]  
        );  
	}

	public static function importTemplateFromFile() {
        require_once WP_PLUGIN_DIR .
            '/elementor/includes/template-library/sources/local.php';

        $filepath = __DIR__ . '/templates/elementor-demo-two-neighborhood.json';
        $filename = pathinfo( $filepath, PATHINFO_BASENAME );

        //echo '<pre>';
        ///print_r('filepath: ' . $filepath);
        //echo '</pre>';

        //echo '<pre>';
        //print_r('filename: ' . $filename);
        //echo '</pre>';

        $local = new \Elementor\TemplateLibrary\Source_Local();

        $local->import_template( $filename, $filepath );
    }

	/**
	 * Import built-in template.
	 */
	private function importBuildInTemplate( $template_file_path ) {
		require_once WP_PLUGIN_DIR . '/elementor/includes/template-library/sources/local.php';
		$local          = new \Elementor\TemplateLibrary\Source_Local();
		$imported_items = $local->import_template(  pathinfo( $template_file_path, PATHINFO_BASENAME ), $template_file_path );
		if ( ! is_wp_error( $imported_items ) ) {
			add_post_meta( $imported_items[0][ 'template_id' ], 'contempo-real-estate-custom-posts::built_in', md5( file_get_contents( $template_file_path ) ) );
		}
	}

	/**
	 * Get built-in templates from plugin files.
	 *
	 * @return Array Templates
	 */
	private function getTemplatesFromPlugin() {
		$templates     = [];
		$templates_dir = __DIR__ . DIRECTORY_SEPARATOR . 'templates';
		$paths         = new \RecursiveIteratorIterator( new \RecursiveDirectoryIterator( $templates_dir ), \RecursiveIteratorIterator::SELF_FIRST );
		foreach ( $paths as $path => $unused ) {
			$path = str_replace( '\\', '/', $path );
			if ( preg_match( '/\/[\w-]+\.json$/', $path ) ) {
				$templates[] = $path;
			}
		}
		return $templates;
	}

	/**
	 * Maybe fire the templates update process.
	 *
	 * The update process will happen if:
	 * - The plugin version saved on the database doesn't match the actual plugin version
	 * - 6 hours at least has passed since the last update
	 */
	public function maybeUpdateTemplates() {

		// Dahsboard only
		if ( ! is_admin() ) {
			return;
		}
		// Administrators only
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		// On normal requests only
		if ( defined( 'DOING_AJAX') && constant( 'DOING_AJAX' ) ) {
			return;
		}

		$do_it          = false;
		$plugin_file    = dirname( __FILE__, 2 ) . DIRECTORY_SEPARATOR . 'ct-real-estate-custom-posts.php';
		$plugin_version = get_plugin_data( $plugin_file )[ 'Version' ];
		if ( $plugin_version !== get_option( 'contempo-real-estate-custom-posts::version' ) ) {
			$do_it = true;
		} else if ( ! get_transient( 'contempo-real-estate-custom-posts::updated' ) ) {
			$do_it = true;
		}
		if ( $do_it ) {
			update_option( 'contempo-real-estate-custom-posts::version', $plugin_version );
			set_transient( 'contempo-real-estate-custom-posts::updated', 1, 6 * HOUR_IN_SECONDS );
			$this->updateTemplates();
		}
	}

	/**
	 * Update templates
	 *
	 * The missing built-in templates will be added.
	 */
	private function updateTemplates() {
		foreach ( $this->getTemplatesFromPlugin() as $template_file_path ) {
			$matching_templates = get_posts( [
				'post_type'  => \Elementor\TemplateLibrary\Source_Local::CPT,
				'meta_key'   => 'contempo-real-estate-custom-posts::built_in',
				'meta_value' => md5( file_get_contents( $template_file_path ) ),
				'fields'     => 'ids',
			] );
			if ( ! $matching_templates ) {
				$this->importBuildInTemplate( $template_file_path );
			}
		};
	}

	/**
	 * Cleanup Options and transients after plugin deactivation
	 */
	public function doDeactivationCleanup() {
		delete_option( 'contempo-real-estate-custom-posts::version' );
		delete_transient( 'contempo-real-estate-custom-posts::updated' );
	}

	/**
	 *  Plugin class constructor
	 *
	 * Register plugin action hooks and filters
	 *
	 * @since 1.2.0
	 * @access public
	 */
	public function __construct() {

		// Register widget scripts
		//add_action( 'elementor/frontend/after_register_scripts', [ $this, 'widget_scripts' ] );

		// Register widgets
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'register_widgets' ] );

		// Register update related callbacks (commented out for a future update)
		//add_action( 'elementor/init', [ $this, 'maybeUpdateTemplates' ] );
		//add_action( 'deactivate_contempo-real-estate-custom-posts/ct-real-estate-custom-posts.php', [ $this, 'doDeactivationCleanup' ] );

	}

}

// Instantiate Plugin Class
Plugin::instance();
