<?php
/**
 * Ajax single listing template preloader
 */
if ( ! defined('ABSPATH')) {
	exit;
}
?>
<!-- LISTING INFO -->
<div class="re7-modal-preloader-row">
	<div class="re7-modal-preloader-column full-width">
		<div class="re7-modal-preloader-base"></div>
		<div class="re7-modal-preloader-base"></div>
		<div class="re7-modal-preloader-base"></div>
		<div class="re7-modal-preloader-base"></div>
		<div class="re7-modal-preloader-base"></div>
		<div class="re7-modal-preloader-base"></div>
		<div class="re7-modal-preloader-base"></div>
	</div>
</div>
<!-- LISTING INFO END -->

